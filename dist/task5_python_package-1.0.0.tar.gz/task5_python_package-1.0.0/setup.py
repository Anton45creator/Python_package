from setuptools import setup, find_packages

setup(
    name='task5_python_package',
    version='1.0.0',
    url='https://git.foxminded.com.ua/Anton1/task5_python-package.git',
    license='',
    author='ThinkPad',
    author_email='Loukik56@mail.py',
    description='A program that counts unique characters in a string.',

    packages=find_packages(where='src'),
    package_dir={'': 'src'},

)
